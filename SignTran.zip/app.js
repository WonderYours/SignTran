// app.js
const defaultAvatarUrl = 'https://mmbiz.qpic.cn/mmbiz/icTdbqWNOwNRna42FI242Lcia07jQodd2FJGIYQfG0LAJGFxM4FbnQP6yfMxBgJ0F3YRqJCJ1aPAK2dQagdusBZg/0'
App({
  onLaunch: function () {
  },
   globalData: {
     age: "18",
     avatarUrl: defaultAvatarUrl,
     nickname:'请点击头像登录',
     text:'中国有句古话，叫做识时务者为俊杰。'
   }
   
})
